from flask import Flask, render_template, request
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

app = Flask(__name__)
df = pd.read_csv('data/faqs.csv')
def clean(s):
    s = str(s).lower()
    s = re.sub(r'[^a-z0-9\s]', '', s)
    return s
df['q_clean'] = df['question'].apply(clean)
vectorizer = TfidfVectorizer()
tfidf = vectorizer.fit_transform(df['q_clean'].tolist())

@app.route('/', methods=['GET', 'POST'])
def index():
    answer = ''
    user = ''
    if request.method == 'POST':
        user = request.form.get('user_query','').strip()
        if user == '':
            answer = "Please type a question."
        else:
            u = clean(user)
            v = vectorizer.transform([u])
            sims = cosine_similarity(v, tfidf)[0]
            idx = sims.argmax()
            score = sims[idx]
            if score < 0.2:
                answer = "Sorry, I did not understand. Try asking about opening hours, borrowing, renewals, or resources."
            else:
                answer = df.iloc[idx]['answer']
    return render_template('index.html', answer=answer, user=user)

if __name__ == '__main__':
    app.run(debug=True)
