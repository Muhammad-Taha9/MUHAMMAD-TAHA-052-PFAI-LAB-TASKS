from flask import Flask, render_template, request
import pandas as pd
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import os
import pickle

app = Flask(__name__)

df = pd.read_csv("data/library_qna.csv")
questions = df['Question'].tolist()
answers = df['Answer'].tolist()

model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

embedding_file = "embeddings/faiss_index.bin"
vector_dim = 384

if os.path.exists(embedding_file):
    with open(embedding_file, "rb") as f:
        index = pickle.load(f)
else:
    question_embeddings = model.encode(questions)
    index = faiss.IndexFlatL2(vector_dim)
    index.add(np.array(question_embeddings, dtype='float32'))
    os.makedirs("embeddings", exist_ok=True)
    with open(embedding_file, "wb") as f:
        pickle.dump(index, f)

@app.route("/", methods=["GET", "POST"])
def home():
    response = ""
    if request.method == "POST":
        user_query = request.form["query"]
        user_vec = model.encode([user_query])
        D, I = index.search(np.array(user_vec, dtype='float32'), k=1)
        response = answers[I[0][0]]
    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(debug=True)
