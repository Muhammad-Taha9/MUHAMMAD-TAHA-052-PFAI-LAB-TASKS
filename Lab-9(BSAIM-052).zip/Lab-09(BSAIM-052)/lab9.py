import re
import nltk
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

nltk.download('stopwords', quiet=True)

stop = set(stopwords.words('english'))
stemmer = PorterStemmer()

def clean_text(s):
    s = s.lower()
    s = re.sub(r'[^a-z0-9\s]', '', s)
    tokens = s.split()
    tokens = [t for t in tokens if t not in stop]
    tokens = [stemmer.stem(t) for t in tokens]
    return " ".join(tokens)

data = {
    'text': [
        'I love this',
        'This is amazing',
        'I hate this',
        'This is terrible',
        'Not bad',
        'Worst experience ever',
        'Very good',
        'I am happy',
        'I am sad',
        'This is boring'
    ],
    'label': [
        'positive',
        'positive',
        'negative',
        'negative',
        'positive',
        'negative',
        'positive',
        'positive',
        'negative',
        'negative'
    ]
}

df = pd.DataFrame(data)
df['clean'] = df['text'].apply(clean_text)
X = df['clean']
y = df['label']

model = make_pipeline(CountVectorizer(), MultinomialNB())
model.fit(X, y)

while True:
    t = input("Enter text: ")
    if t.lower() == "exit":
        break
    c = clean_text(t)
    p = model.predict([c])
    print("Sentiment:", p[0])
