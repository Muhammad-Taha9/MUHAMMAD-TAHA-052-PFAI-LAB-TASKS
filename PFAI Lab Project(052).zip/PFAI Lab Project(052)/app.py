﻿from flask import Flask, request, redirect, url_for, send_file, render_template
from datetime import datetime
from io import BytesIO
import matplotlib.pyplot as plt

from database import get_db, init_db
from model import predict_mood

app = Flask(__name__)

init_db()

@app.route('/')
def index():
    db = get_db()
    cur = db.execute('SELECT id, text, mood, created_at FROM entries ORDER BY id DESC')
    rows = cur.fetchall()
    return render_template('index.html', rows=rows)

@app.route('/add', methods=['POST'])
def add_entry():
    text = request.form.get('entry', '').strip()
    if text == '':
        return redirect(url_for('index'))
    mood = predict_mood(text)
    created_at = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    db = get_db()
    db.execute('INSERT INTO entries (text, mood, created_at) VALUES (?, ?, ?)', (text, mood, created_at))
    db.commit()
    return redirect(url_for('index'))

@app.route('/clear')
def clear_entries():
    db = get_db()
    db.execute('DELETE FROM entries')
    db.commit()
    return redirect(url_for('index'))

@app.route('/mood_plot.png')
def mood_plot():
    db = get_db()
    cur = db.execute('SELECT mood, COUNT(*) as cnt FROM entries GROUP BY mood')
    data = cur.fetchall()
    moods = [row['mood'] for row in data]
    counts = [row['cnt'] for row in data]

    order = ['happy', 'neutral', 'sad', 'angry']
    ordered_counts = [0]*len(order)
    for i, m in enumerate(order):
        if m in moods:
            ordered_counts[i] = counts[moods.index(m)]

    fig, ax = plt.subplots(figsize=(6,3))
    ax.bar(order, ordered_counts)
    ax.set_title('Mood Counts')
    ax.set_ylabel('Number of entries')
    ax.set_ylim(0, max(1, max(ordered_counts)))

    buf = BytesIO()
    plt.tight_layout()
    fig.savefig(buf, format='png')
    plt.close(fig)
    buf.seek(0)
    return send_file(buf, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
