﻿from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

TRAIN_TEXTS = [
    "I am very happy today, had a great day",
    "I feel sad and lonely",
    "I am angry about what happened",
    "I am excited and joyful",
    "Feeling depressed and tired",
    "I am upset and frustrated",
    "I am calm and content",
    "Today was wonderful and fun",
    "I am worried and anxious",
    "I feel peaceful",
    "I had a terrible day, so angry",
    "I am cheerful and energetic"
]

TRAIN_LABELS = [
    "happy", "sad", "angry", "happy", "sad", "angry",
    "neutral", "happy", "sad", "neutral", "angry", "happy"
]

model_pipeline = make_pipeline(CountVectorizer(), MultinomialNB())
model_pipeline.fit(TRAIN_TEXTS, TRAIN_LABELS)

def predict_mood(text: str) -> str:
    return model_pipeline.predict([text])[0]
